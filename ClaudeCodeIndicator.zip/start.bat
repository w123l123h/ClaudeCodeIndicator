@echo off
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

REM 检查 TCP 54321 是否已被占用（单实例保护）
netstat -ano 2>nul | findstr ":54321.*LISTENING" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo Another instance is already running (port 54321 in use).
    exit /b 0
)

C:\Users\joe06\AppData\Local\Programs\Python\Python313\python.exe "%SCRIPT_DIR%desktop-relay\main.py"
pause
