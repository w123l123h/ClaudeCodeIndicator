#!/usr/bin/env python3
"""
Claude Code Hook 通知脚本
由 Claude Code settings.json hooks 调用，将状态事件通过 TCP 发送给桌面中继。
"""
import socket
import sys

TCP_HOST = "127.0.0.1"
TCP_PORT = 54321
TIMEOUT = 2  # 秒


def send_message(msg):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(TIMEOUT)
        sock.connect((TCP_HOST, TCP_PORT))
        sock.sendall((msg + "\n").encode())
        sock.close()
    except (socket.timeout, ConnectionRefusedError, OSError):
        # 主程序未运行，静默忽略
        pass


def main():
    if len(sys.argv) < 2:
        sys.exit(0)

    event_type = sys.argv[1]

    # 事件 → 消息映射
    event_map = {
        "tool_start": "WORKING",
        "waiting_user": "WAITING_USER",
        "complete": "COMPLETED",
        "error": "ERROR",
    }

    msg = event_map.get(event_type)
    if msg:
        send_message(msg)


if __name__ == "__main__":
    main()
