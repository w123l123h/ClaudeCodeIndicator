@echo off
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

C:\Users\joe06\AppData\Local\Programs\Python\Python313\python.exe "%SCRIPT_DIR%installer\install.py"
pause
