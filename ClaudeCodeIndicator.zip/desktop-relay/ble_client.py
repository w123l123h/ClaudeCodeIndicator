import asyncio
import logging
from bleak import BleakScanner, BleakClient

from config import (
    BLE_SERVICE_UUID, BLE_CHAR_UUID, BLE_SCAN_TIMEOUT,
    BLE_DEVICE_NAME_PREFIX, DEVICE_CONFIG_FILE,
    RECONNECT_BASE_DELAY, RECONNECT_MAX_DELAY, RECONNECT_BACKOFF_MULTIPLIER,
)

logger = logging.getLogger(__name__)


class BleClientManager:
    def __init__(self):
        self._client: BleakClient | None = None
        self._char = None
        self._connected = False
        self._message_callback = None
        self._target_device = None

    def set_message_callback(self, cb):
        self._message_callback = cb

    @property
    def is_connected(self):
        return self._connected and self._client and self._client.is_connected

    def get_saved_device(self):
        import os
        if os.path.exists(DEVICE_CONFIG_FILE):
            import json
            with open(DEVICE_CONFIG_FILE, 'r') as f:
                data = json.load(f)
                return data.get('device_name')
        return None

    def save_device(self, name):
        import json
        with open(DEVICE_CONFIG_FILE, 'w') as f:
            json.dump({'device_name': name}, f)

    async def scan_and_connect(self):
        saved = self.get_saved_device()

        if saved:
            logger.info(f"Looking for saved device: {saved}")
            device = await self._scan_for_device(saved)
        else:
            logger.info("No saved device, scanning all...")
            device = await self._scan_for_device(BLE_DEVICE_NAME_PREFIX)

        if device:
            self._target_device = device.name
            await self._connect(device.address)
            return True
        return False

    async def _scan_for_device(self, name_filter):
        logger.info(f"Scanning for '{name_filter}'...")
        devices = await BleakScanner.discover(timeout=BLE_SCAN_TIMEOUT)

        for d in devices:
            if d.name and name_filter in d.name:
                logger.info(f"Found: {d.name} ({d.address})")
                return d
        return None

    async def _connect(self, address):
        self._client = BleakClient(address, disconnected_callback=self._on_disconnect)
        await self._client.connect()
        self._connected = True
        logger.info(f"Connected to {address}")

        # 发现 service/characteristic
        for service in self._client.services:
            if service.uuid == BLE_SERVICE_UUID:
                for char in service.characteristics:
                    if char.uuid == BLE_CHAR_UUID:
                        self._char = char
                        await self._client.start_notify(char.uuid, self._on_notify)
                        logger.info("Characteristic found, notify enabled")
                        break

    def _on_disconnect(self, client):
        logger.warning("BLE disconnected")
        self._connected = False

    def _on_notify(self, sender, data):
        msg = data.decode().strip()
        logger.info(f"Notify: {msg}")
        if self._message_callback:
            self._message_callback(msg)

    async def send(self, message):
        if self._client and self._char:
            data = (message + '\n').encode()
            await self._client.write_gatt_char(self._char.uuid, data)
            logger.info(f"Sent: {message}")

    async def disconnect(self):
        if self._client:
            await self._client.disconnect()
            self._connected = False

    async def reconnect_loop(self):
        delay = RECONNECT_BASE_DELAY
        while True:
            if not self.is_connected:
                logger.info(f"Reconnecting in {delay}s...")
                await asyncio.sleep(delay)
                success = await self.scan_and_connect()
                if success:
                    delay = RECONNECT_BASE_DELAY
                else:
                    delay = min(delay * RECONNECT_BACKOFF_MULTIPLIER, RECONNECT_MAX_DELAY)
            else:
                await asyncio.sleep(1)
