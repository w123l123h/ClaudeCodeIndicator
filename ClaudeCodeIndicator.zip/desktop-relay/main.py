import asyncio
import logging
import sys
import os

# 确保工作目录为项目根 (desktop-relay 的父目录)
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    KEEPALIVE_INTERVAL, KEEPALIVE_RESPONSE_TIMEOUT, KEEPALIVE_MAX_FAILURES,
)
from ble_client import BleClientManager
from tcp_server import TcpRelayServer
from pairing import show_pairing_dialog

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s'
)
logger = logging.getLogger("main")


class DesktopRelay:
    def __init__(self):
        self.ble = BleClientManager()
        self.tcp = TcpRelayServer(self.ble.send)
        self.alive_event = asyncio.Event()
        self.keepalive_failures = 0

        self.ble.set_message_callback(self._on_ble_message)

    def _on_ble_message(self, msg):
        logger.info(f"BLE notify: {msg}")
        if msg == "ALIVE":
            self.alive_event.set()

    async def _pairing_flow(self):
        """首次配对流程"""
        saved = self.ble.get_saved_device()
        if saved:
            logger.info(f"Already paired with: {saved}")
            return True

        # 连接后发送 PAIR_CONFIRM
        await self.ble.send("PAIR_CONFIRM")
        await asyncio.sleep(0.5)

        # 弹出对话框
        loop = asyncio.get_event_loop()
        confirmed = await loop.run_in_executor(
            None, show_pairing_dialog, self.ble._target_device
        )

        if confirmed:
            self.ble.save_device(self.ble._target_device)
            await self.ble.send("PAIR_SUCCESS")
            logger.info("Pairing successful")
            return True
        else:
            await self.ble.disconnect()
            logger.info("Pairing cancelled by user")
            return False

    async def _keepalive_task(self):
        while True:
            await asyncio.sleep(KEEPALIVE_INTERVAL)
            if not self.ble.is_connected:
                continue

            try:
                self.alive_event.clear()
                await self.ble.send("KEEPALIVE")

                await asyncio.wait_for(
                    self.alive_event.wait(),
                    timeout=KEEPALIVE_RESPONSE_TIMEOUT
                )
                self.keepalive_failures = 0
                logger.debug("Keepalive OK")
            except asyncio.TimeoutError:
                self.keepalive_failures += 1
                logger.warning(f"Keepalive timeout ({self.keepalive_failures}/{KEEPALIVE_MAX_FAILURES})")

                if self.keepalive_failures >= KEEPALIVE_MAX_FAILURES:
                    logger.error("Keepalive failed — forcing reconnect")
                    await self.ble.disconnect()
                    self.keepalive_failures = 0

    async def run(self):
        # 扫描 + 连接
        connected = await self.ble.scan_and_connect()
        if not connected:
            logger.error("No device found")
            return

        # 配对
        paired = await self._pairing_flow()
        if not paired:
            return

        # 启动 TCP
        await self.tcp.start()

        # 并发：保活 + 重连监视
        await asyncio.gather(
            self._keepalive_task(),
            self.ble.reconnect_loop(),
        )


if __name__ == "__main__":
    relay = DesktopRelay()
    try:
        asyncio.run(relay.run())
    except KeyboardInterrupt:
        logger.info("Shutting down...")
