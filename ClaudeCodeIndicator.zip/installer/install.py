#!/usr/bin/env python3
"""
Claude Code Indicator 安装程序
1. 安装 Python 依赖 (bleak)
2. 配置 Claude Code hooks
"""
import subprocess
import sys
import json
import os
from pathlib import Path

PYTHON_EXE = r"C:\Users\joe06\AppData\Local\Programs\Python\Python313\python.exe"
SCRIPT_DIR = Path(__file__).parent.parent.resolve()
HOOK_SCRIPT = str(SCRIPT_DIR / "hook-notifier" / "notify.py")


def install_deps():
    """安装所需 Python 依赖"""
    print("Checking dependencies...")
    try:
        import bleak
        print("  bleak: installed")
    except ImportError:
        print("  bleak: installing...")
        subprocess.check_call(
            [PYTHON_EXE, "-m", "pip", "install", "bleak"],
            stdout=sys.stdout, stderr=sys.stderr
        )
        print("  bleak: installed successfully")


def setup_hooks():
    """配置 Claude Code hooks"""
    settings_path = Path.home() / ".claude" / "settings.json"

    # 读取现有配置
    settings = {}
    if settings_path.exists():
        with open(settings_path, 'r') as f:
            settings = json.load(f)

    # 确保 hooks 段存在
    if "hooks" not in settings:
        settings["hooks"] = {}

    # 添加 hook 配置
    settings["hooks"]["PostToolUse"] = [
        {
            "matcher": "*",
            "hooks": [
                {
                    "type": "command",
                    "command": f'"{PYTHON_EXE}" "{HOOK_SCRIPT}" tool_start'
                }
            ]
        }
    ]

    # 写入
    os.makedirs(settings_path.parent, exist_ok=True)
    with open(settings_path, 'w') as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)

    print(f"Hooks configured in: {settings_path}")


def verify():
    """验证安装"""
    errors = []

    # 检查 bleak
    try:
        import bleak
        print("  [OK] bleak available")
    except ImportError:
        errors.append("bleak not installed")

    # 检查 settings.json
    settings_path = Path.home() / ".claude" / "settings.json"
    if settings_path.exists():
        with open(settings_path) as f:
            data = json.load(f)
            if "hooks" in data:
                print(f"  [OK] settings.json configured")
            else:
                errors.append("hooks not found in settings.json")
    else:
        errors.append("settings.json not found")

    if errors:
        print(f"\nWARNING: {len(errors)} issue(s):")
        for e in errors:
            print(f"  - {e}")
    else:
        print("\nInstallation successful!")


if __name__ == "__main__":
    print("=== Claude Code Indicator Installer ===\n")
    install_deps()
    setup_hooks()
    verify()
